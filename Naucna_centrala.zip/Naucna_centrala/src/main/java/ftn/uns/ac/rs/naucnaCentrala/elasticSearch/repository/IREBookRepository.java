package ftn.uns.ac.rs.naucnaCentrala.elasticSearch.repository;

import ftn.uns.ac.rs.naucnaCentrala.elasticSearch.model.PaperIndexUnit;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IREBookRepository extends ElasticsearchRepository<PaperIndexUnit, String> {
}
