package ftn.uns.ac.rs.naucnaCentrala.model;

public enum ScientificFieldName {
	ECOLOGY,
	BIOLOGY,
	MATHEMATICS,
	LOGIC,
	ENGINEERING
}
