package ftn.uns.ac.rs.naucnaCentrala.elasticSearch.service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.elasticsearch.core.ElasticsearchTemplate;
import org.springframework.stereotype.Service;

import ftn.uns.ac.rs.naucnaCentrala.elasticSearch.handler.PdfDocumentHandler;
import ftn.uns.ac.rs.naucnaCentrala.repository.ArticleRepository;

@Service
public class ESPaperService {

	private IREBookRepository irEbookRepository;

    private ArticleRepository eBookRepository;

    private PdfDocumentHandler pdfDocumentHandler;

    private Path dirLocation;

    private ElasticsearchTemplate elasticsearchTemplate;

    @Autowired
    public EBookService(StorageProperties properties,
                        IREBookRepository irEbookRepository,
                        EBookRepository eBookRepository,
                        PdfDocumentHandler pdfDocumentHandler,
                        ElasticsearchTemplate elasticsearchTemplate) {
        this.dirLocation = Paths.get(properties.getLocation());
        this.irEbookRepository = irEbookRepository;
        this.eBookRepository = eBookRepository;
        this.pdfDocumentHandler = pdfDocumentHandler;
        this.elasticsearchTemplate = elasticsearchTemplate;
    }
	public void init() {
        try {
            Files.createDirectories(dirLocation);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
