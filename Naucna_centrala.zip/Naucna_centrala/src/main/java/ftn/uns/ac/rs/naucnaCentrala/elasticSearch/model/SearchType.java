package ftn.uns.ac.rs.naucnaCentrala.elasticSearch.model;

public enum SearchType {
	
		regular,
		fuzzy,
		phrase,
		range,
		prefix

}
