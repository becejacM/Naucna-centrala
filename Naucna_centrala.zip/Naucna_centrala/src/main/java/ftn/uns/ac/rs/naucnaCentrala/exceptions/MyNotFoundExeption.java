package ftn.uns.ac.rs.naucnaCentrala.exceptions;

public class MyNotFoundExeption extends RuntimeException {

    public MyNotFoundExeption() {
        super();
    }

    public MyNotFoundExeption(String message) {
        super(message);
    }

}
