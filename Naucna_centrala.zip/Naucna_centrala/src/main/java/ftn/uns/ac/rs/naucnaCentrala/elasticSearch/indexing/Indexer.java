package ftn.uns.ac.rs.naucnaCentrala.elasticSearch.indexing;

import org.springframework.stereotype.Service;

import ftn.uns.ac.rs.naucnaCentrala.elasticSearch.model.PaperIndexUnit;
import ftn.uns.ac.rs.naucnaCentrala.elasticSearch.repository.IREBookRepository;

@Service
public class Indexer {

    private IREBookRepository ireBookRepository;

    public Indexer(IREBookRepository ireBookRepository) {
        this.ireBookRepository = ireBookRepository;
    }

    public PaperIndexUnit add(PaperIndexUnit ebook) {
        return ireBookRepository.index(ebook);
    }

    public PaperIndexUnit update(PaperIndexUnit ebook) {
        return ireBookRepository.save(ebook);
    }

    public void delete(PaperIndexUnit ebook) {
        ireBookRepository.delete(ebook);
    }
}
