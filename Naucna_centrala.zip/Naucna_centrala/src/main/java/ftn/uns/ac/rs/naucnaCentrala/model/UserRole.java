package ftn.uns.ac.rs.naucnaCentrala.model;

public enum UserRole {
    AUTHOR,
    EDITOR,
    REVIEWER
}
