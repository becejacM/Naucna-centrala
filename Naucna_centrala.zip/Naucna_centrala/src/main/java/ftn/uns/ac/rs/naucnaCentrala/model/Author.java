package ftn.uns.ac.rs.naucnaCentrala.model;

import javax.persistence.Entity;

@Entity
public class Author extends AppUser{

	public Author() {
		
	}
	
	
}
