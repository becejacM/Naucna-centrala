package ftn.uns.ac.rs.naucnaCentrala.model;

public enum PaymentMethod {

	OPEN_ACCESS,		//naplacuje se autorima objava rada
	WITH_SUBSCRIPTION 	//naplacuje se citaocima pristup radovima
}
